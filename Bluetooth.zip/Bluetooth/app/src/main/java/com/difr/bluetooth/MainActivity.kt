package com.difr.bluetooth

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.difr.bluetooth.databinding.ActivityMainBinding
import java.io.IOException
import java.util.*
import kotlin.collections.ArrayList
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    lateinit var bAdapter:BluetoothAdapter
    lateinit var binding:ActivityMainBinding

    private val REQUEST_CODE_ENABLE_BT:Int = 1
    private val REQUEST_CODE_DISCOVERABLE_BT:Int = 2

    val list : ArrayList<BluetoothDevice> = ArrayList()
    var bSocket : BluetoothSocket? = null
    var uuid : UUID = UUID.fromString("00000000-0000-1000-8000-00805F9B34FB")
    val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    override  fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        binding=ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



        binding.btOff.setBackgroundColor(Color.parseColor("#FFC4C4C4"))
        binding.btSearch.setBackgroundColor(Color.parseColor("#FF9C9B9B"))
   binding.btKnow.setBackgroundColor(Color.parseColor("#FF676666"))



        binding.btOff.isEnabled=false
        binding.btSearch.isEnabled=false
        // binding.btKnow.isEnabled=false

        bAdapter=BluetoothAdapter.getDefaultAdapter()
        if(bluetoothAdapter==null){
//Device doesn'tsupportBluetooth
        }

        if(bAdapter.isEnabled){
            binding.ivBluetooth.setImageResource(R.drawable.bt_on)
        }else{
            binding.ivBluetooth.setImageResource(R.drawable.bt_off)
        }


        binding.btOn.setOnClickListener(){
            if(bAdapter.isEnabled){
                Toast.makeText(this,"ENCENDIDO",Toast.LENGTH_SHORT).show()
            }else{
                val intent=Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(intent,REQUEST_CODE_ENABLE_BT)
            }
        }
        binding.btOff.setOnClickListener(){
            if(!bAdapter.isEnabled){
                Toast.makeText(this,"APAGADO",Toast.LENGTH_SHORT).show()
            }else{
                binding.btOn.setBackgroundColor(Color.parseColor("#08508A"))
                binding.btOff.setBackgroundColor(Color.parseColor("#FFC4C4C4"))
                binding.btSearch.setBackgroundColor(Color.parseColor("#FF9C9B9B"))
                //binding.btKnow.setBackgroundColor(Color.parseColor("#FF676666"))

                binding.btOn.isEnabled=true
                binding.btOff.isEnabled=false
                binding.btSearch.isEnabled=false
                // binding.btKnow.isEnabled=true
                if(ActivityCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    )!=PackageManager.PERMISSION_GRANTED
                ){

                }
                bAdapter.disable()

                binding.tvDevices.text=""
                binding.ivBluetooth.setImageResource(R.drawable.bt_off)
                Toast.makeText(this,"BLUETOOTHAPAGADO",Toast.LENGTH_SHORT).show()
            }
        }


        binding.btSearch.setOnClickListener(){
            val discoverableIntent:Intent=Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply{
            putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION,600)
        }
            startActivity(discoverableIntent)

        }

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when(requestCode){
            REQUEST_CODE_ENABLE_BT ->
                if(resultCode == Activity.RESULT_OK){
                    binding.ivBluetooth.setImageResource(R.drawable.bt_on)
                    Toast.makeText(this,"BLUETOOTH ENCENDIDO",Toast.LENGTH_SHORT).show()
                    binding.btOn.isEnabled = false
                    binding.btOff.isEnabled = true
                    binding.btSearch.isEnabled = true


                    binding.btOn.setBackgroundColor(Color.parseColor("#FFE0E0E0"))
                    binding.btOff.setBackgroundColor(Color.parseColor("#297DC1"))
                    binding.btSearch.setBackgroundColor(Color.parseColor("#60AEEC"))
                    binding.btKnow.setBackgroundColor(Color.parseColor("#8BBADF"))
                }else{
                    Toast.makeText(this,"BLUETOOTH NO SE PUEDE HABILITAR",Toast.LENGTH_SHORT).show()
                }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }


}